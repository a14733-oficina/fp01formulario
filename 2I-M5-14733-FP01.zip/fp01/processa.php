<?php
$nome=$_POST["nome"];
$idade= $_POST["idade"];
$senha = $_POST["senha"];
$tamanho = strlen($senha);
if($idade >18){
    $idadeTexto = "adulto👴";
} elseif ($idade < 12) {
    $idadeTexto = "criança👶";
}else{
    $idadeTexto = "adolescente🧑";
}
echo "Ola $nome,bem vindo!<br>";
echo "$nome tu és $idadeTexto!<br>";
if($tamanho > 8){
    echo "<span style='color: #008000;;'>Password forte!🟩</span></p>";
}elseif($tamanho < 5){
    echo "<span style='color: #ff0000;;'>Password fraca!🟥</span></p>";
}else{
    echo "<span style='color: #8b8d0779;;'>Password media!🟨</span></p>";
}
?> 